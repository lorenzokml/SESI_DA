#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>

// Pinos conectados
const int pinoBuzzer = 18;
const int pinoLED    = 19;
const int pinoBotao  = 4;

// Limiares de movimento
const float LIMIAR_QUEDA_LIVRE = 0.4; 
const float LIMIAR_IMPACTO     = 2.8; 

Adafruit_MPU6050 mpu;

void setup() {
  Serial.begin(115200);
  
  pinMode(pinoBuzzer, OUTPUT);
  pinMode(pinoLED, OUTPUT);
  
  // Mudamos aqui: desativamos o pullup interno para evitar o falso clique
  pinMode(pinoBotao, INPUT); 

  if (!mpu.begin()) {
    Serial.println("Erro: Verifique os fios do MPU6050!");
    while (1) delay(10);
  }
  Serial.println("=== Pulseira IoT Ajustada ===");
}

void loop() {
  sensors_event_t a, g, temp;
  mpu.getEvent(&a, &g, &temp);

  float ax = a.acceleration.x;
  float ay = a.acceleration.y;
  float az = a.acceleration.z;
  float acc_total = sqrt(ax*ax + ay*ay + az*az);
  float forca_g = acc_total / 9.81; 

  if (forca_g < LIMIAR_QUEDA_LIVRE || forca_g > LIMIAR_IMPACTO) {
    Serial.print("Movimento suspeito! Força G: ");
    Serial.println(forca_g);
    Serial.println("Alarme disparado! Aguardando o botao...");
    
    bool paradoPeloUsuario = false;
    unsigned long tempoDoAlarme = millis();

    while (millis() - tempoDoAlarme < 10000) {
      
      // Ajuste de leitura: agora ele só cancela se ler energia (HIGH) vinda do botão
      if (digitalRead(pinoBotao) == HIGH) {
        paradoPeloUsuario = true;
        break; 
      }

      digitalWrite(pinoLED, HIGH);
      digitalWrite(pinoBuzzer, HIGH);
      delay(150);
      digitalWrite(pinoLED, LOW);
      digitalWrite(pinoBuzzer, LOW);
      delay(150);
    }

    if (paradoPeloUsuario) {
      Serial.println("-> Botao pressionado: Usuario cancelou o alarme!");
      digitalWrite(pinoLED, LOW);
      digitalWrite(pinoBuzzer, LOW);
      delay(3000); 
    } else {
      Serial.println("-> PERIGO: Usuario NAO respondeu nos 10 segundos!");
      digitalWrite(pinoLED, HIGH);
      digitalWrite(pinoBuzzer, HIGH);
      delay(4000);
      digitalWrite(pinoLED, LOW);
      digitalWrite(pinoBuzzer, LOW);
    }
  }
  delay(100);
}
